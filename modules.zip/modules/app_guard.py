import psutil, subprocess, time, shlex

# =========================================================
# 🔍 MONITORING APLIKACJI
# =========================================================
def tool_APP_GUARD(arg, system_tool, log):
    """
    Monitorowanie i automatyczne wznawianie aplikacji.
    Przykład:
      TOOL: APP_GUARD | lutris
      TOOL: APP_GUARD | flatpak run net.lutris.Lutris
    """

    ALIASES = {
        "lutris": "lutris",
        "brave": "brave-browser",
        "firefox": "firefox",
    }

    target = arg.strip()
    if not target:
        return "Użycie: TOOL: APP_GUARD | <nazwa procesu | komenda>"

    # aliasy po ludzku
    target = ALIASES.get(target.lower(), target)

    log(f"[APP_GUARD] start monitoringu dla: {target}")

    result = ""
    found = False

    # --- sprawdzanie czy proces działa ---
    for p in psutil.process_iter(["name", "pid"]):
        pname = p.info.get("name") or ""
        if target.lower() in pname.lower():
            found = True
            result += f"✅ Proces '{pname}' działa (PID {p.info['pid']})\n"
            break

    # --- restart jeśli nie działa ---
    if not found:
        result += f"⚠️ Proces '{target}' nie działa – uruchamiam ponownie...\n"
        try:
            cmd = shlex.split(target)
            subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            result += f"✅ Uruchomiono ponownie: {target}\n"
        except Exception as e:
            result += f"❌ Nie udało się uruchomić {target}: {e}\n"

    # --- wykrywanie wysokiego zużycia zasobów ---
    high_usage = []
    for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
        if (p.info.get("cpu_percent", 0) > 90 or
            p.info.get("memory_percent", 0) > 60):
            high_usage.append(p.info)

    if high_usage:
        result += "\n⚠️ Procesy o wysokim zużyciu zasobów:\n"
        for h in high_usage:
            result += (
                f"  {h.get('name','?')} (PID {h['pid']}) – "
                f"{h.get('cpu_percent',0)}% CPU, "
                f"{h.get('memory_percent',0):.1f}% RAM\n"
            )

    result += "\n🛡️ APP_GUARD zakończył kontrolę."
    return result

