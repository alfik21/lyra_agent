import re
from datetime import datetime

def tool_LOG_ANALYZE(arg, system_tool, log):
    """
    Analizuje treść logów (np. systemowych, Xorg, Cinnamon)
    i tłumaczy je na ludzki język. Pobiera ostatnie 100 linii z pliku logu,
    interpretuje znane wzorce błędów i zwraca raport tekstowy.
    Argument `arg` może zawierać ścieżkę do pliku logu; jeżeli jest pusty,
    używa domyślnego pliku ~/.xsession-errors.
    """
    try:
        # jeśli nie podano ścieżki – bierzemy ~/.xsession-errors
        path = arg.strip() or "~/.xsession-errors"
        # Pobierz ostatnie 100 linii z pliku logu. Jeśli plik nie istnieje, system_tool zwróci błąd.
        output = system_tool(f"tail -n 100 {path}", timeout=5)
        explanations = []
        # proste heurystyki do rozpoznawania częstych błędów
        lower_out = output.lower()
        if "ebusy" in lower_out or "resource busy" in lower_out:
            explanations.append("🧩 System zgłasza 'resource busy' – czyli zasób (np. karta graficzna lub sesja Xorg) jest już zajęty przez inny proces. Cinnamon próbował przejąć ekran, ale GNOME/Xorg już działa.")
        if "mutter" in lower_out or "muffin" in lower_out:
            explanations.append("🎨 'mutter' i 'muffin' to menedżery okien Cinnamon i GNOME. Jeśli obydwa próbują działać naraz – dochodzi do konfliktu i sesja graficzna się nie uruchamia.")
        if "respawning too quickly" in lower_out:
            explanations.append("♻️ Proces powłoki Cinnamon próbuje się restartować zbyt często – prawdopodobnie crash loop. Warto sprawdzić motywy lub rozszerzenia Cinnamon.")
        if "gnome-shell" in lower_out:
            explanations.append("🪟 GNOME przejął kontrolę nad sesją – Cinnamon nie wystartował.")
        if "failed to start" in lower_out:
            explanations.append("❌ Aplikacja Cinnamon nie uruchomiła się – często to wina uszkodzonego motywu lub błędnego pakietu `cinnamon-settings-daemon`.")
        if not explanations:
            explanations.append("✅ Nie znaleziono poważnych błędów – sesja graficzna wygląda na stabilną.")

        text = f"=== Analiza logu {path} ({datetime.now().strftime('%H:%M:%S')}) ===\n\n{output[-800:]}\n\n"
        text += "\n".join(explanations)
        # Zapisz raport w osobnym pliku logów, aby ułatwić późniejszą analizę
        log(text, "log_analyzer.log")
        return text
    except Exception as e:
        return f"[Błąd LOG_ANALYZE] {e}"