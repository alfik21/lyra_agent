from pathlib import Path
import json

MODELS_DIR = Path("/media/tomek/arhiwum/AI_MODELS")
MAP_FILE = MODELS_DIR / "models.json"

def tool_MODEL_LIST(arg, system, log):
    if not MAP_FILE.exists():
        return "[Lyra] Brak pliku models.json – uruchom: lyra aktualizuj modele"

    data = json.loads(MAP_FILE.read_text())

    active = data.get("active", "")
    available = data.get("available", {})

    msg = "📦 Dostępne modele lokalne:\n\n"
    
    for name, path in available.items():
        flag = " (AKTYWNY)" if name == active else ""
        msg += f" • {name}{flag}\n"
        msg += f"    ↳ {path}\n"

    msg += "\nUżyj: lyra użyj <model>\n"

    return msg

