import subprocess

def run(cmd):
    return subprocess.getoutput(cmd)

