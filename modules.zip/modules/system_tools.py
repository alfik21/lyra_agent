import psutil, subprocess, os, re, time

# =========================================================
# 🩺 DIAGNOZA SYSTEMU
# =========================================================
def tool_SYSTEM_DIAG(arg, system_tool, log):
    try:
        cpu = psutil.cpu_percent(interval=2)
        ram = psutil.virtual_memory()
        swap = psutil.swap_memory()
        uptime = system_tool("uptime -p").strip()
        temps = system_tool("sensors | grep '°C' | head -n 5")

        diag = (
            f"🩺 Diagnoza systemu:\n"
            f"- Uptime: {uptime}\n"
            f"- CPU użycie: {cpu}%\n"
            f"- RAM: {ram.used // (1024**2)} MB / {ram.total // (1024**2)} MB\n"
            f"- SWAP: {swap.used // (1024**2)} MB / {swap.total // (1024**2)} MB\n"
            f"- Temperatura (top 5):\n{temps}\n"
            f"- Liczba procesów: {len(psutil.pids())}\n"
        )

        top_proc = sorted(
            [(p.info["pid"], p.info["name"], p.info["cpu_percent"])
             for p in psutil.process_iter(["pid", "name", "cpu_percent"])],
            key=lambda x: x[2],
            reverse=True
        )[:5]

        diag += "\n🔥 TOP 5 procesów CPU:\n"
        for pid, name, cpu_p in top_proc:
            diag += f"  {pid} {name} – {cpu_p}% CPU\n"

        return diag
    except Exception as e:
        return f"[Błąd SYSTEM_DIAG] {e}"


# =========================================================
# 🔧 NAPRAWA / AUTO-OPTIMIZE
# =========================================================
def tool_SYSTEM_FIX(arg, system_tool, log):
    try:
        cmds = [
            "sudo apt update -y",
            "sudo apt --fix-broken install -y",
            "sudo apt autoremove -y",
            "sudo apt clean",
        ]
        output = "🔧 Naprawa systemu pakietów (APT):\n"
        for c in cmds:
            output += f"\n→ {c}\n{system_tool(c, timeout=60)}\n"
        return output
    except Exception as e:
        return f"[Błąd SYSTEM_FIX] {e}"


def tool_AUTO_OPTIMIZE(arg, system_tool, log):
    try:
        actions = [
            "sync; echo 3 | sudo tee /proc/sys/vm/drop_caches",
            "sudo systemctl restart systemd-logind",
            "sudo journalctl --vacuum-time=3d",
        ]
        result = "⚙️ Auto-Optymalizacja systemu:\n"
        for a in actions:
            result += f"\n→ {a}\n"
            result += system_tool(a, timeout=15)
        result += "\n✅ System zoptymalizowany."
        return result
    except Exception as e:
        return f"[Błąd AUTO_OPTIMIZE] {e}"
