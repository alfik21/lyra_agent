from pathlib import Path
import json
from datetime import datetime

class MemoryStore:
    def __init__(self, path: Path):
        self.path = path
        if not self.path.exists():
            self.path.write_text("[]", encoding="utf-8")

    def load(self):
        return json.loads(self.path.read_text(encoding="utf-8"))

    def append(self, entry: dict):
        mem = self.load()
        mem.append(entry)
        self.path.write_text(
            json.dumps(mem, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )

    def remember_text(self, user, assistant):
        self.append({
            "time": datetime.now().isoformat(),
            "type": "TEXT",
            "user": user,
            "assistant": assistant
        })

