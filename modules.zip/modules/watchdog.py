import psutil, time, subprocess
from datetime import datetime

def tool_WATCHDOG(arg, system_tool, log):
    """
    Prosty czuwak systemowy – monitoruje CPU, RAM, sieć i procesy.
    Można uruchomić ręcznie albo w tle przez systemd timer.
    """
    log("=== START WATCHDOG ===")

    cpu = psutil.cpu_percent(interval=3)
    ram = psutil.virtual_memory().percent
    net = psutil.net_io_counters()
    total_sent = net.bytes_sent // (1024**2)
    total_recv = net.bytes_recv // (1024**2)

    result = (
        f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"🧠 CPU: {cpu}% | 💾 RAM: {ram}% | 🌐 TX/RX: {total_sent}/{total_recv} MB\n"
    )

    # reakcje automatyczne
    actions = []
    if cpu > 90:
        actions.append("Wysokie użycie CPU – sprawdź top procesy.")
    if ram > 85:
        actions.append("Pamięć prawie pełna – czyszczę cache.")
        system_tool("sync; echo 3 | sudo tee /proc/sys/vm/drop_caches")
    if not actions:
        actions.append("System stabilny ✅")

    result += "\n".join(f"→ {a}" for a in actions)
    log(result, "watchdog.log")
    return result
