import json
from pathlib import Path

MODELS_DIR = Path("/media/tomek/arhiwum/AI_MODELS")
MAP_FILE = MODELS_DIR / "models.json"

# ===========================================
# LISTA MODELI
# ===========================================

def list_models() -> str:
    if not MAP_FILE.exists():
        return "❌ Brak pliku models.json – uruchom: lyra aktualizuj modele"

    data = json.loads(MAP_FILE.read_text("utf-8"))
    models = data.get("available", {})

    out = ["📦 Dostępne modele AI:\n"]
    for name in models.keys():
        out.append(f" • {name}")

    return "\n".join(out)


# ===========================================
# ZMIANA AKTYWNEGO MODELU
# ===========================================

def use_model(model_name: str, log):
    if not MAP_FILE.exists():
        return "❌ models.json nie istnieje — najpierw: lyra aktualizuj modele"

    data = json.loads(MAP_FILE.read_text("utf-8"))
    models = data.get("available", {})

    if model_name not in models:
        return f"❌ Model '{model_name}' nie istnieje w katalogu AI_MODELS.\nUżyj: lyra modele"

    # zapisujemy jako aktywny model
    data["active"] = model_name
    MAP_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False))

    log(f"ACTIVE MODEL SET → {model_name}", "models.log")
    return f"✅ Ustawiono aktywny model: {model_name}"


# ===========================================
# ROUTER POLECEŃ
# ===========================================

def tool_MODEL_SWITCHER(arg: str, log):
    arg = arg.strip().lower()

    if arg == "" or arg == "lista":
        return list_models()

    if arg.startswith("użyj "):
        model = arg.replace("użyj ", "").strip()
        return use_model(model, log)

    if arg == "odśwież":
        return "SYSTEM: bash ~/update_ai_models.sh"

    return "❌ Nieznana komenda przełącznika modeli"

