import speech_recognition as sr
import subprocess, time

def tool_VOICE_INPUT(arg, system_tool, log):
    """
    Nasłuchuje mikrofon i przekazuje rozpoznany tekst do Lyry.
    """
    recognizer = sr.Recognizer()
    mic = sr.Microphone()
    print("🎤 Powiedz coś do Lyry...")

    with mic as source:
        recognizer.adjust_for_ambient_noise(source, duration=1)
        audio = recognizer.listen(source, phrase_time_limit=6)

    try:
        text = recognizer.recognize_google(audio, language="pl-PL")
        print(f"🗣️ Rozpoznano: {text}")
        log(f"[VOICE] Rozpoznano: {text}", "voice.log")
        subprocess.run(["lyra", text])
        return f"🎧 Komenda głosowa: {text}"
    except sr.UnknownValueError:
        return "❌ Nie zrozumiałam – powiedz jeszcze raz."
    except Exception as e:
        return f"[Błąd VOICE_INPUT] {e}"
