import json, os, sys

MODELS_PATH = os.path.expanduser("~/lyra_agent/models.json")

def load_models():
    if not os.path.exists(MODELS_PATH):
        data = {"active": "mistral", "available": {"mistral": "mistral:latest"}}
        save_models(data)
        return data
    with open(MODELS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def save_models(data):
    with open(MODELS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# ===================================
# 🧩 Główne narzędzie Lyry
# ===================================

def tool_MODEL_MANAGER(arg, system_tool, log):
    """
    Zarządza lokalnymi modelami AI: dodawanie, usuwanie, przełączanie, lista.
    """
    args = arg.strip().split()
    models = load_models()

    if not args:
        return f"🔍 Aktywny model: {models['active']}\nDostępne: {', '.join(models['available'].keys())}"

    action = args[0].lower()

    # === DODAWANIE ===
    if action == "dodaj" and len(args) >= 3:
        name, tag = args[1], args[2]
        models["available"][name] = tag
        save_models(models)
        return f"✅ Dodano nowy model: {name} → {tag}"

    # === USUWANIE ===
    if action == "usuń" and len(args) >= 2:
        name = args[1]
        if name in models["available"]:
            del models["available"][name]
            save_models(models)
            return f"🗑️ Usunięto model: {name}"
        return f"❌ Nie znaleziono modelu: {name}"

    # === ZMIANA / AKTYWACJA ===
    if action in ["zmień", "aktywuj"] and len(args) >= 2:
        name = args[1]
        if name not in models["available"]:
            return f"❌ Model '{name}' nie istnieje. Użyj: 'lyra dodaj model {name} tag'"
        models["active"] = name
        save_models(models)
        return f"✅ Aktywowano model: {name} ({models['available'][name]})"

    # === LISTA ===
    if action in ["lista", "pokaż"]:
        lines = [f"🔍 Aktywny model: {models['active']}"]
        lines.append("📦 Dostępne modele:")
        for k, v in models["available"].items():
            lines.append(f" - {k}: {v}")
        return "\n".join(lines)

    return "⚙️ Dostępne polecenia: dodaj, usuń, zmień, pokaż"

