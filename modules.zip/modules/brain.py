# modules/brain.py
import subprocess

def query_brain(prompt: str) -> str:
    """
    Lokalny 'mózg' Lyry – zapytanie do Ollamy (Mistral).
    """
    try:
        cmd = ["ollama", "run", "mistral", prompt]
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120
        )
        return result.stdout.strip()
    except Exception as e:
        return f"[Błąd mózgu lokalnego] {e}"

