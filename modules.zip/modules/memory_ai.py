import os, json, re
from datetime import datetime, timedelta

LOG_DIR = os.path.expanduser("~/lyra_agent/logs")

def tool_MEMORY_ANALYZE(arg, system_tool, log):
    """
    Analizuje logi i historię działań Lyry.
    Uczy się, które komendy pomogły i które błędy się powtarzają.
    """
    result = "🧠 Analiza pamięci Lyry:\n"
    try:
        recent = []
        for file in os.listdir(LOG_DIR):
            if file.endswith(".log"):
                path = os.path.join(LOG_DIR, file)
                mtime = datetime.fromtimestamp(os.path.getmtime(path))
                if mtime > datetime.now() - timedelta(days=7):
                    with open(path, "r", encoding="utf-8", errors="ignore") as f:
                        recent += f.readlines()

        summary = {
            "audio_fixes": len(re.findall(r"pipewire|alsa|audio", " ".join(recent), re.I)),
            "net_fixes": len(re.findall(r"ping|nmcli|network|dns", " ".join(recent), re.I)),
            "system_errors": len(re.findall(r"error|failed|traceback", " ".join(recent), re.I)),
            "optimizations": len(re.findall(r"optimize|drop_caches|autoremove", " ".join(recent), re.I)),
        }

        result += (
            f"- Błędy systemowe: {summary['system_errors']}\n"
            f"- Naprawy sieci: {summary['net_fixes']}\n"
            f"- Naprawy dźwięku: {summary['audio_fixes']}\n"
            f"- Optymalizacje: {summary['optimizations']}\n"
        )

        if summary["audio_fixes"] > 2:
            result += "\n🎧 Wygląda na to, że często naprawiam dźwięk – może ustawić automatyczne monitorowanie PipeWire?"
        if summary["net_fixes"] > 3:
            result += "\n🌐 Często pojawia się problem z siecią – mogę ustawić auto-ping co 5 minut."
        if summary["system_errors"] > 5:
            result += "\n⚠️ Dużo błędów w logach – warto zrobić `lyra zoptymalizuj system`."

        log(result, "memory_ai.log")
        return result
    except Exception as e:
        return f"[Błąd MEMORY_ANALYZE] {e}"
