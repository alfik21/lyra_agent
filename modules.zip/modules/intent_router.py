import re

def detect_intent(user_prompt: str) -> tuple[str, str]:
    """
    Analizuje tekst użytkownika i wybiera nazwę narzędzia (TOOL) + argument.
    ZAWSZE zwraca tuple (tool, arg) – nigdy None.
    """

    p = user_prompt.lower().strip()

    # ================================
    # 💽 1. DYSKI / SYSTEM PLIKÓW
    # ================================
    if any(k in p for k in [
        "sprawdź dyski", "pokaż dyski", "dyski",
        "partycje", "system plików", "wolne miejsce",
        "ile mam miejsca"
    ]):
        return ("DISK_DIAG", "")

    # ================================
    # 🌐 2. SIEĆ
    # ================================
    if any(word in p for word in ["internet", "sieć", "wifi", "ping"]):
        if "napraw" in p or "restart" in p:
            return ("NET_FIX", p)
        elif "diagnoz" in p or "sprawdź" in p:
            return ("NET_DIAG", p)
        return ("NET_INFO", p)

    # ================================
    # 🔊 3. AUDIO
    # ================================
    if any(word in p for word in ["dźwięk", "audio", "głośność", "mikrofon"]):
        if "napraw" in p or "restart" in p:
            return ("AUDIO_FIX", p)
        elif "diagnoz" in p or "sprawdź" in p:
            return ("AUDIO_DIAG", p)

    # ================================
    # 🖥️ 4. SYSTEM / CPU / RAM / UPDATE
    # ================================
    if any(word in p for word in ["procesor", "cpu", "ram", "system", "kernel", "update", "aktualizuj"]):
        if "napraw" in p or "opt" in p:
            return ("SYSTEM_FIX", p)
        elif "diagnoz" in p or "sprawdź" in p:
            return ("SYSTEM_DIAG", p)
        return ("AUTO_OPTIMIZE", p)

    # ================================
    # 📦 5. APLIKACJE
    # ================================
    if any(word in p for word in ["uruchom", "otwórz", "program", "aplikację"]):
        return ("APP_CONTROL", p)

    # ================================
    # 🛡️ 6. OCHRONA APLIKACJI
    # ================================
    if any(word in p for word in ["monitoruj", "pilnuj", "chroń", "guard"]):
        return ("APP_GUARD", p)

    # ================================
    # 🖥️ 7. TMUX / EKRAN
    # ================================
    if "ekran" in p or "tmux" in p:
        return ("TMUX_SCREEN_DIAG", p)

    # ================================
    # 🔚 BRAK DOPASOWANIA
    # ================================
    return ("", "")

