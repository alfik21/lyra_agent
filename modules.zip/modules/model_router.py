import requests, subprocess, json, os
from datetime import datetime
import json, os

BASE_DIR = os.path.expanduser("~/lyra_agent")
MEMORY_PATH = os.path.join(BASE_DIR, "agent_memory.json")

def internet_ok():
    """Sprawdza czy jest internet (ping 8.8.8.8)"""
    try:
        subprocess.check_call(
            ["ping", "-c", "1", "8.8.8.8"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        return True
    except Exception:
        return False

def save_to_memory(prompt, answer, source):
    """Zapisuje odpowiedź do pamięci Lyry"""
    try:
        if not os.path.exists(MEMORY_PATH):
            with open(MEMORY_PATH, "w", encoding="utf-8") as f:
                json.dump([], f)
        mem = json.load(open(MEMORY_PATH, "r", encoding="utf-8"))
        mem.append({
            "time": datetime.now().isoformat(),
            "prompt": prompt.strip(),
            "answer": answer.strip(),
            "source": source
        })
        json.dump(mem, open(MEMORY_PATH, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[Błąd zapisu pamięci] {e}")

def search_memory(prompt):
    """Szybkie przeszukiwanie historii odpowiedzi"""
    try:
        if not os.path.exists(MEMORY_PATH):
            return None
        mem = json.load(open(MEMORY_PATH, "r", encoding="utf-8"))
        for m in reversed(mem[-50:]):  # tylko ostatnie 50 wpisów
            if m["prompt"].lower() in prompt.lower() or prompt.lower() in m["prompt"].lower():
                return m["answer"]
        return None
    except Exception:
        return None

def query_model(prompt, local_model, cloud_model, client, messages):
    import json, os

    STATE_PATH = os.path.expanduser("~/lyra_agent/system_state.json")
    mode = "auto"
    if os.path.exists(STATE_PATH):
        try:
            with open(STATE_PATH, "r", encoding="utf-8") as f:
                mode = json.load(f).get("mode", "auto")
        except Exception:
            pass

    # jeśli tryb offline wymuszony
    if mode == "offline":
        return "[Tryb offline] Pracuję tylko lokalnie — bez internetu.", "offline"

    # jeśli tryb online wymuszony — pomiń lokalne modele
    if mode == "online":
        if internet_ok():
            try:
                resp = client.chat.completions.create(model=cloud_model, messages=messages)
                msg = resp.choices[0].message.content
                save_to_memory(prompt, msg, "cloud")
                return msg, "cloud"
            except Exception as e:
                return f"[Błąd GPT-5.1] {e}", "error"
        else:
            return "[Brak internetu] Tryb online nieosiągalny.", "error"



    """
    Próbuje odpowiedzieć w kolejności:
    1️⃣ Lokalna pamięć
    2️⃣ Lokalny model (Ollama)
    3️⃣ GPT-5.1 w chmurze
    4️⃣ Tryb offline (gdy nic nie działa)
    """
    # 1️⃣ Pamięć
    mem_answer = search_memory(prompt)
    if mem_answer:
        return f"[Z pamięci] {mem_answer}", "memory"
        
        
          # jeśli tryb offline wymuszony
    if mode == "offline":
        return "[Tryb offline] Pracuję tylko lokalnie — bez internetu.", "offline"

    # jeśli tryb online wymuszony — pomiń lokalne modele
    if mode == "online":
        if internet_ok():
            try:
                resp = client.chat.completions.create(model=cloud_model, messages=messages)
                msg = resp.choices[0].message.content
                save_to_memory(prompt, msg, "cloud")
                return msg, "cloud"
            except Exception as e:
                return f"[Błąd GPT-5.1] {e}", "error"
        else:
            return "[Brak internetu] Tryb online nieosiągalny.", "error"
  
        
        

    # 2️⃣ Lokalny model
    try:
        resp = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": local_model, "prompt": prompt},
            timeout=30
        )
        data = resp.json()
        if "response" in data and data["response"].strip():
            save_to_memory(prompt, data["response"], "local")
            return data["response"], "local"
    except Exception:
        pass

    # 3️⃣ Internet / GPT-5.1
    if internet_ok():
        try:
            resp = client.chat.completions.create(model=cloud_model, messages=messages)
            msg = resp.choices[0].message.content
            save_to_memory(prompt, msg, "cloud")
            return msg, "cloud"
        except Exception as e:
            return f"[Błąd GPT-5.1] {e}", "error"

    # 4️⃣ Brak internetu i model lokalny nie zadziałał
    return "[Tryb offline] Brak internetu lub lokalny model nie odpowiedział.", "offline"

