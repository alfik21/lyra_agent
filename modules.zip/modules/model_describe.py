import json
from pathlib import Path

MODELS_DIR = Path("/media/tomek/arhiwum/AI_MODELS")
MAP_FILE = MODELS_DIR / "models.json"

# Opisy modeli – z czasem będziemy rozszerzać
MODEL_DESCRIPTIONS = {
    "bielik": "Polski model 11B, dobry do zadań ogólnych, tłumaczeń, rozmów i kodu.",
    "bielik-11b": "Mocna polska LLM, solidna w zadaniach ogólnych i technicznych.",
    "mistral": "Lekki, szybki model 7B. Idealny do pracy offline i szybkich odpowiedzi.",
    "mistral-nemo": "Mistral ulepszony przez NVIDIA – lepsze rozumienie techniczne.",
    "mixtral": "Model 8x7B – duża moc przy zachowaniu rozsądnych wymagań sprzętowych.",
    "gemma": "Model Google – świetny w rozumowaniu i naturalnym języku.",
    "qwen2.5": "Bardzo dobry w logice, Pythonie, analizie danych i matematyce.",
    "deepseek": "Model zoptymalizowany pod myślenie krok-po-kroku (CoT).",
    "llama": "Meta Llama – wysoka jakość w zrozumieniu tekstu i kodzie.",
    "aya": "Model wielojęzyczny, dobry do zadań tłumaczeniowych.",
    "granite": "IBM Granite – silny model do zadań technicznych.",
    "stable-code": "Specjalizowany model do pisania i analizowania kodu.",
    "phi": "Model od Microsoft – świetny do edukacji i prostych zadań.",
    "llava": "Model multi-modalny – potrafi opisywać obrazy (jeśli podłączysz).",
}

def normalize(name):
    return name.lower().replace("_", "-").replace(".", "-")

def describe_model(name):
    key = normalize(name)
    for k, v in MODEL_DESCRIPTIONS.items():
        if k in key:
            return v
    return "Brak opisu – nowy lub nieznany model."

def tool_MODEL_DESCRIBE(arg, system, log):
    if not MAP_FILE.exists():
        return "[Lyra] Brak pliku models.json – uruchom: lyra aktualizuj modele"

    data = json.loads(MAP_FILE.read_text())
    available = data.get("available", {})

    msg = "📘 Opisy dostępnych modeli:\n\n"

    for name, path in available.items():
        desc = describe_model(name)
        msg += f"🔹 **{name}**\n"
        msg += f"    ↳ {path}\n"
        msg += f"    📝 {desc}\n\n"

    msg += "Użyj: lyra użyj <model>\n"

    return msg

